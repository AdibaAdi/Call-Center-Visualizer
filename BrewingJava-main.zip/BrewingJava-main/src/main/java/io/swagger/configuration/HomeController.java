package io.swagger.configuration;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Home redirection to swagger api documentation 
 */
@Controller
public class HomeController {
    @RequestMapping(value = "/")
    public String index() {
//        System.out.println("/swagger-ui/index.html");
        return "redirect:https://brewing-java-wyklx6zl2a-uw.a.run.app/api/v3/index.html";
    }
    // Login form
    @RequestMapping("/login")
    public String login() {
        return "login.html";
    }
}
