package io.swagger.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.model.Agent;
import io.swagger.model.CustomUserDetails;
import io.swagger.service.AgentsService;
import io.swagger.service.CustomUserDetailsService;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.security.Principal;
import java.util.List;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2022-10-31T01:09:17.482Z[GMT]")
@RestController
public class AgentsApiController implements AgentsApi {

    private static final Logger log = LoggerFactory.getLogger(AgentsApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    // object that represents data of all agents
    @Autowired
    private final AgentsService agentsService;
    @Autowired
    private final CustomUserDetailsService userDetailsService;
    @Autowired
    public AgentsApiController(ObjectMapper objectMapper,
                               HttpServletRequest request,
                               AgentsService agentsService,
                               CustomUserDetailsService userDetailsService) {
        this.objectMapper = objectMapper;
        this.request = request;
        this.agentsService = agentsService;
        this.userDetailsService = userDetailsService;
    }

    public ResponseEntity<List<Agent>> findAgentsByStatus(@Parameter(in = ParameterIn.QUERY, description = "Status values that need to be considered for filter" ,schema=@Schema(allowableValues={ "afterCall", "break", "busy", "lunch", "notReady", "off", "preCall", "ready" }
    )) @Valid @RequestParam(value = "status", required = false) String status) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                // TODO: call your class to get real data and put it instead of hardcoded string below
                return new ResponseEntity<List<Agent>>(objectMapper.readValue("[ {\n  \"firstName\" : \"John\",\n  \"lastName\" : \"James\",\n  \"id\" : 10,\n  \"agentStatus\" : 1\n}, {\n  \"firstName\" : \"John\",\n  \"lastName\" : \"James\",\n  \"id\" : 10,\n  \"agentStatus\" : 1\n} ]", List.class), HttpStatus.OK);
            } catch (Exception e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<Agent>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<Agent>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<List<Agent>> getAgents(Principal principal) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                CustomUserDetails user = (CustomUserDetails) this.userDetailsService.loadUserByUsername(principal.getName());
                if (user.getOrgId() != null) {
                    return new ResponseEntity<List<Agent>>(agentsService.fetchAgentByOrgId(user.getOrgId()), HttpStatus.OK);
                } else {
                    return new ResponseEntity<List<Agent>>(agentsService.fetchAgentList(), HttpStatus.OK);
                }
            } catch (Exception e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<List<Agent>>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<List<Agent>>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Agent> getAgentsById(@Parameter(in = ParameterIn.PATH, description = "ID of pet to return", required=true, schema=@Schema()) @PathVariable("agentId") String agentId) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                // TODO: call your class to get real data and put it instead of hardcoded string below
                return new ResponseEntity<Agent>(agentsService.fetchAgentById(agentId), HttpStatus.OK);
            } catch (Exception e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<Agent>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<Agent>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<Agent> postAgentsById(@Parameter(in = ParameterIn.PATH, description = "ID of pet to return", required=true, schema=@Schema()) @PathVariable("agentId") String agentId,@Parameter(in = ParameterIn.DEFAULT, description = "Update agent state by ID", required=true, schema=@Schema()) @Valid @RequestBody Agent body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<Agent>(agentsService.updateAgent(body, agentId), HttpStatus.OK);
            } catch (Exception e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<Agent>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<Agent>(HttpStatus.NOT_IMPLEMENTED);
    }

}
