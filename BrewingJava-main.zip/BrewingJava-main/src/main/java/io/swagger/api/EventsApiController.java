package io.swagger.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.model.Agent;
import io.swagger.model.CustomUserDetails;
import io.swagger.model.Event;
import io.swagger.service.AgentsService;
import io.swagger.service.CustomUserDetailsService;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.security.Principal;
import java.util.List;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2022-10-31T01:09:17.482Z[GMT]")
@RestController
public class EventsApiController implements EventsApi {

    private static final Logger log = LoggerFactory.getLogger(EventsApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    // object that represents data of all agents
    @Autowired
    private final AgentsService agentsService;
    @Autowired
    private final CustomUserDetailsService userDetailsService;
    @Autowired
    public EventsApiController(ObjectMapper objectMapper,
                               HttpServletRequest request,
                               AgentsService agentsService,
                               CustomUserDetailsService userDetailsService) {
        this.objectMapper = objectMapper;
        this.request = request;
        this.agentsService = agentsService;
        this.userDetailsService = userDetailsService;
    }

    public ResponseEntity<Agent> postAgentsEvent(Principal principal, @Parameter(in = ParameterIn.DEFAULT, description = "Update agent state from event", required=true, schema=@Schema()) @Valid @RequestBody Event body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                CustomUserDetails user = (CustomUserDetails) this.userDetailsService.loadUserByUsername(principal.getName());
                if ( !body.getHeader().getOrgId().equals(user.getOrgId()) ) { return new ResponseEntity<Agent>(HttpStatus.FORBIDDEN); }

                Agent agent = body.getPayload().getAgentInfo();
                agent.setAgentStatus(body.getPayload().getAgentState());
                agent.setOrgId(user.getOrgId());
                return new ResponseEntity<Agent>(agentsService.updateAgent(agent, agent.getId()), HttpStatus.OK);
            } catch (Exception e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<Agent>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<Agent>(HttpStatus.NOT_IMPLEMENTED);
    }

}
