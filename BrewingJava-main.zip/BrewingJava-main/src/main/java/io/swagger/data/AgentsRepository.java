package io.swagger.data;

import io.swagger.model.Agent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AgentsRepository extends JpaRepository<Agent, String> {
    @Query("select a from Agent a where a.orgId = ?1")
    List<Agent> findByOrgId(String orgId);
}

