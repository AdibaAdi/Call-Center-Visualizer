package io.swagger.service;

import io.swagger.data.AgentsRepository;
import io.swagger.model.Agent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Objects;

@Service
public class AgentsServiceImpl implements AgentsService {

    @Autowired
    private AgentsRepository agentsRepository;

    @Override
    public Agent saveAgent(Agent agent) {
        return agentsRepository.save(agent);
    }

    @Override
    public List<Agent> fetchAgentList() {
        return agentsRepository.findAll();
    }
    @Override
    public Agent fetchAgentById(String agentId) {
        return agentsRepository.findById(agentId).get();
    }

    @Override
    public List<Agent> fetchAgentByOrgId(String orgId) { return agentsRepository.findByOrgId(orgId); }

    @Override
    public Agent updateAgent(Agent agent, String agentId) {
        Agent agentDB;
        try {
            agentDB = agentsRepository.findById(agentId).get();
        } catch (NoSuchElementException e) {
            agentDB = new Agent();
            agentDB.setId(agentId);
        }

        if (Objects.nonNull(agent.getEmail())
                && !"".equalsIgnoreCase(agent.getEmail())) {
            agentDB.setEmail(agent.getEmail());
        }

        if (Objects.nonNull(agent.getName())
                && !"".equalsIgnoreCase(agent.getName())) {
            agentDB.setName(agent.getName());
        }
//
//        if (Objects.nonNull(agent.getLastName())
//                && !"".equalsIgnoreCase(agent.getLastName())) {
//            agentDB.setLastName(agent.getLastName());
//        }

        if (Objects.nonNull(agent.getAgentStatus())) {
            agentDB.setAgentStatus(agent.getAgentStatus());
        }

        if (Objects.nonNull(agent.getOrgId())) {
            agentDB.setOrgId(agent.getOrgId());
        }

        return agentsRepository.save(agentDB);
    }

    @Override
    public void deleteAgentById(String agentId) {
        agentsRepository.deleteById(agentId);
    }
}
