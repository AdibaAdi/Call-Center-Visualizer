package io.swagger.service;

import io.swagger.model.Agent;

import java.util.List;

// Interface
public interface AgentsService {

    // Save operation
    Agent saveAgent(Agent agent);

    // Read operation
    List<Agent> fetchAgentList();
    Agent fetchAgentById(String agentId);
    List<Agent> fetchAgentByOrgId(String orgId);

    // Update operation
    Agent updateAgent(Agent agent,
                           String agentId);

    // Delete operation
    void deleteAgentById(String agentId);
}
