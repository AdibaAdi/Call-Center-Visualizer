package io.swagger.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.validation.annotation.Validated;

@Validated
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EventHeader {
//    private String subscriptionId;
    @JsonProperty("orgId")
    private String orgId;
//    private String domainId;
    @JsonProperty("eventId")
    private String eventId;
//    private String eventTimestamp;
    @JsonProperty("eventGroup")
    private String eventGroup;
    @JsonProperty("eventName")
    private String eventName;
}
