package io.swagger.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.validation.annotation.Validated;

import javax.persistence.Entity;

@Validated
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Event {
    @JsonProperty("header")
    private EventHeader header;
    @JsonProperty("payload")
    private EventPayload payload;
}
