package io.swagger.model;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import org.springframework.validation.annotation.Validated;

import javax.persistence.*;

/**
 * Agent
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2022-10-31T01:09:17.482Z[GMT]")

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "agents")
@Entity
public class Agent {
  @JsonProperty("agentStatus")
  @Column(length = 40)
  private String agentStatus = null;

  @JsonProperty("email")
  @Column(length = 80)
  private String email = null;

  @JsonProperty("name")
  @Column(length = 80)
  private String name = null;

//  @JsonProperty("lastName")
//  @Column(length = 80)
//  private String lastName = null;

  @Id
  @JsonProperty("id")
  @Column(nullable = false, length = 80)
  private String id;

  @JsonProperty("orgId")
  @Column(nullable = false, length = 80)
  private String orgId;
}
