/* --- Variables --- */
/*Canvas*/
const c = document.getElementById("myCanvas");
var width = (c.width = window.innerWidth);
var height = (c.height = window.innerHeight);
const ctx = c.getContext("2d");
/*Gap*/
var rad;
var gap1;
var gap2;
var nRows = 1;
var nCols = 1;
const buffer = 10;
/*---*/
/*------*/
/*Agents*/
//var agents = [];//stores the agents
var agentsGrid = new Map(); //stores relative position on grid
var ids = [];
var agentsMap = new Map();
var currentIndex = 0;
const nCap = 10000; //number of max agents
var off; //number of agents offline
var s1; //number of agents available
var s2; //number of agents on a call
var s3; //number of agents on worksheet
var s4; //number of agents on preview task
var currentId;
/*Display*/
var demostate = 0;
var displayId = 0;
var isBtn = true;
var isStable;
/*-------*/
/*Color Palet*/
//const stateNames = ["Offline","Available","VoiceCall","Worksheet","Preview Task"];
//var stateColors = ['cornflowerblue','cyan','mediumblue','blue','midnightblue'];
// hardcoded state names - should be taken from backend
//var stateNames = []; // will be filled in dynamically
//var stateColors = []; // will be filled in dynamically
//var states = []; // counters
var selectTask = 0;
/*------*/
// let hasSwatchyRun = false; //Color Palet
/*------------*/
/*Popup Menu*/
let modal = document.querySelector(".modal-wrapper");
let btn = document.querySelector("button");
let close_btn = document.querySelector(".modal-close");
/*----------*/
/*Agent Info*/
let detail = document.querySelector(".detail-wrapper");
let close1_btn = document.querySelector(".detail-close");
/*----------*/
/* ----------------- */
/* --- States Class --- */
class States {
  constructor() {
    this.states = new Map();
  }
  getColor(state) {
    return this.states.get(state)[0];
  }
  setColor(state, color) {
    this.states.get(state)[0] = color;
  }
  getCount(state) {
    return this.states.get(state)[1];
  }
  getAllStates() {
    return this.states;
  }
  increment(state) {
    if (!this.states.has(state)) {
      const randomColor = "#" + Math.floor(Math.random()*16777215).toString(16);
      this.states.set(state, [randomColor, 0])
      renderLegend();
    }
    this.states.get(state)[1] += 1;
  }
  resetAll() {
    for (let [k, v] of this.states) {
      v[1] = 0;
    }
  }
}
var states = new States();
/* --- Agent Class --- */
class circle {
  constructor(
    X = null,
    Y = null,
    rad = null,
    color = null,
    id = null,
    state = null,
    spot = null,
    name = "",
    email = ""
  ) {
    this.X = X; //position
    this.Y = Y; //position
    this.rad = rad; //radius
    this.color = color;
    this.id = id; //agent id
    this.state = state; //agent state
    this.spot = spot;
    this.name = name;
    this.email = email;
    this.isMouseIn = false;
  }
  clear() {
    ctx.clearRect(
      this.X - this.rad - gap1,
      this.Y - this.rad - gap2,
      this.X + this.rad + gap1,
      this.Y + this.rad + gap2
    );
  }
  circUp(x, y, rad) {
    this.X = x;
    this.Y = y;
    this.rad = rad;
  }
  online(id) {
    this.id = id;
    //        this.stateChange(1);
  }
  stateChange(state) {
    if (state != null) {
      this.state = state;
      states.increment(state);
      this.color = states.getColor(state);
    }
//    this.state = code;
//    if (code >= states.length || code == null) {
//      this.color = stateColors[0];
//      states[0]++;
//    } else {
//      this.color = stateColors[code];
//      states[code]++;
//    }
    this.update();
  }
  update() {
    this.clear();
    ctx.fillStyle = this.color;
    ctx.beginPath();
    ctx.arc(this.X, this.Y, this.rad, degToRad(0), degToRad(360));
    ctx.fill();
    if ((displayId == 1) & (this.id != null)) {
      ctx.strokeStyle = "white";
      ctx.strokeText(this.id, this.X - this.rad, this.Y);
    }
//    if (isStable) {
//      ctx.strokeStyle = "red";
//      ctx.font = "30px Veranda";
//      ctx.strokeText(
//        agentsMap.get(currentIndex).id,
//        agentsMap.get(currentIndex).X - agentsMap.get(currentIndex).rad,
//        agentsMap.get(currentIndex).Y +
//          Math.min(15, agentsMap.get(currentIndex).rad)
//      );
//    }
  }
}
/* ------------------- */

/* --- Functions --- */
/*Mouse Position*/
function getMousePos(e) {
  var rect = c.getBoundingClientRect();
  return {
    x: e.clientX - rect.left,
    y: e.clientY - rect.top,
  };
}
function myFunction(e) {
  var x = e.clientX;
  var y = e.clientY;
  var pos = getMousePos(e);
  var statusText = "";
  isStable = showId(pos);
  if (isStable) {
    if (currentId != null) {
      if (isStable) {
        ctx.strokeStyle = "red";
        ctx.font = "30px Veranda";
        ctx.strokeText(
          agentsMap.get(currentIndex).id,
          agentsMap.get(currentIndex).X - agentsMap.get(currentIndex).rad,
          agentsMap.get(currentIndex).Y +
            Math.min(15, agentsMap.get(currentIndex).rad)
        );
      }
      document.getElementById("AgId").innerHTML = currentId;
      document.getElementById("AgName").innerHTML = agentsMap.get(currentIndex).name;
      statusText = agentsMap.get(currentIndex).state;
      document.getElementById("AgStatus").innerHTML = statusText;
    }
  }
}
function showId(mousePos) {
  var show;
  for (let [id, agent] of agentsMap) {
    show = isMouseIn(mousePos, agent);
    if (show == true) {
      currentIndex = agent.id;
      return show;
    }
  }
  return false;
}
function isMouseIn(pos, circ) {
  function pythag(a, b) {
    var newA = a ** 2;
    var newB = b ** 2;
    var c = newA + newB;
    return Math.sqrt(c);
  }
  var tempx = Math.abs(pos.x - circ.X);
  var tempy = Math.abs(pos.y - circ.Y);
  var newR = pythag(tempx, tempy);
  if (newR <= circ.rad) {
    currentId = circ.id;
    return true;
  }
  return false;
}
/*--------------*/

/*Popup Menu*/
function display() {
  document.getElementById("popup").style.animation = "modalin 1s forwards";
  modal.style.display = "block";
  btn.style.display = "none";
  isBtn = false;
  gaps();
}
function hide() {
  document.getElementById("popup").style.animation = "modalout 1s forwards";
  setTimeout(function () {
    modal.style.display = "none";
  }, 1000);
  btn.style.display = "block";
  isBtn = true;
}
/*----------*/

/*Button Functions*/
function startDemo() {
  if (demostate == 0) {
    demostate = 1;
    document.querySelector("#startBtn").innerHTML = "Stop Demo";
  } else {
    demostate = 0;
    document.querySelector("#startBtn").innerHTML = "Start Demo";
  }
}
function startDisplay() {
  if (displayId == 0) {
    displayId = 1;
    document.querySelector("#idOnBtn").innerHTML = "Turn Off ID";
  } else {
    displayId = 0;
    document.querySelector("#idOnBtn").innerHTML = "Turn On ID";
  }
}

/* -------New Color Changer for Legend---------- */
// set event listenster for color input from dot class and set color of stateColors
function colorChange(event) {
  var color = event.target.value;
  var id = event.target.id;
  var state = id.substring(5);
  console.log("Change color for state: " + state);
  states.setColor(state, color);
  document.querySelector("." + state).style.backgroundColor = color;
}

function setupColorChanger() {
  document.querySelectorAll(".dot").forEach((item) => {
    item.addEventListener("change", (event) => {
      colorChange(event);
    });
    item.addEventListener("input", (event) => {
      colorChange(event);
    });
  });
}
/* ----------------- */
/*Agent Info*/
function displayAgentInfo(e) {
  console.log("agent info")
  var x = e.clientX;
  var y = e.clientY;
  var pos = getMousePos(e);
  var statusText = "";
  isStable = showId(pos);
  if (isStable) {
    if (currentId != null) {
      document.getElementById("AgId").innerHTML = currentId;
      document.getElementById("AgName").innerHTML = agentsMap.get(currentIndex).name;
      statusText = agentsMap.get(currentIndex).state;
      document.getElementById("AgStatus").innerHTML = statusText;
    }
  }
  if (isStable) {
    document.getElementById("detail_popup").style.animation =
      "detailin 1s forwards";
    detail.style.display = "block";
  }
}
function hideAgentInfo() {
  document.getElementById("detail_popup").style.animation =
    "detailout 1s forwards";
  setTimeout(function () {
    detail.style.display = "none";
  }, 1000);
}
/*----------*/

/*Agents*/
//function createAgent(x, y, r){
//    agents.push(new circle(x, y, r));
//}
function random(n) {
  return Math.floor(Math.random() * n);
}
/*------*/

/*Canvas*/
function degToRad(degrees) {
  return (degrees * Math.PI) / 180;
}
function reset() {
  //resets all variables
  width = c.width = window.innerWidth - 40;
  if (isBtn) {
    height = c.height = window.innerHeight - 65;
  } else {
    height = c.height = window.innerHeight - 50;
  }
  gap1 = 1;
  gap2 = 1;
}

function gaps() {
  //creates the size for each agent
  reset();
  var radWidth;
  var radHeight;
  if (agentsMap.size + 1 > nRows * nCols) {
    if (agentsMap.size < nCap) {
      if (nCols > (nRows * width) / height) {
        nRows++;
      } else {
        nCols++;
      }
    }
  }
  radWidth = (width - gap1 * (nCols + 1) - buffer) / nCols / 2;
  radHeight = (height - gap2 * (nRows + 1) - buffer) / nRows / 2;
  //to determine which radius will fit both directions
  if (radWidth > radHeight) {
    rad = radHeight;
    gap1 = (width - buffer - nCols * 2 * rad) / (nCols - 1);
  } else {
    rad = radWidth;
    gap2 = (height - buffer - nRows * 2 * rad) / (nRows - 1);
  }
  gapsUpdate();
}

function gapsUpdate() {
  //creates the location for each agent
  var m = rad + buffer / 2; // y coordinate
  var idIndex = 0;
  for (var j = 0; j < nRows; j++) {
    var n = rad + buffer / 2; // x coordinate
    for (var i = 0; i < nCols; i++) {
      if (idIndex >= ids.length) return; // we are done with all agents

      var newGridSpot = gridSpot(i, j);
      if (!agentsGrid.has(newGridSpot)) {
        // found empty spot - assign  unassigned agentId to the agentsGrid
        for (let [id, agent] of agentsMap) {
          if (!agent.spot) {
            // found unassigned agent
            agentsGrid.set(newGridSpot, id);
            agentsMap.get(id).spot = newGridSpot;
            break;
          }
        }
        //                agentsGrid.set(newGridSpot, ids[idIndex]);
      }
      agentCircle = agentsMap.get(agentsGrid.get(newGridSpot));
      if (!agentCircle) continue; // agent is not assigned to this spot - skip
      agentCircle.circUp(n, m, rad);
      agentCircle.update();
      idIndex++;
      n += 2 * rad + gap1;
    }
    m += 2 * rad + gap2;
  }
}

function gridSpot(x, y) {
  // Returns Excel like grid spot - A1, BX42, etc.
  var newSpot;
  var nx = -1;
  var cols = [
    "A",
    "B",
    "C",
    "D",
    "E",
    "F",
    "G",
    "H",
    "I",
    "J",
    "K",
    "L",
    "M",
    "N",
    "O",
    "P",
    "Q",
    "R",
    "S",
    "T",
    "U",
    "V",
    "W",
    "X",
    "Y",
    "Z",
  ];
  while (x >= cols.length) {
    nx++;
    x -= cols.length;
  }
  if (nx >= 0) {
    newSpot = cols[nx] + cols[x] + y;
  } else {
    newSpot = cols[x] + y;
  }
  return newSpot;
}

function getAllAgents() {
  var myHeaders = new Headers();
  myHeaders.append("Accept", "application/json");
  //    myHeaders.append("api_key", "<API Key>");

  var requestOptions = {
    method: "GET",
    headers: myHeaders,
    redirect: "follow",
  };

  fetch("/api/v3/agents", requestOptions)
    .then((response) => response.text())
    .then((result) => updateAgents(result))
    .catch((error) => console.log("error", error));
}

function updateAgents(agentStates) {
  var agentsObj = JSON.parse(agentStates);
  for (var i = 0; i < agentsObj.length; i++) {
    var id = agentsObj[i].id;
    if (!ids.includes(id)) {
      // populate ids
      ids.push(id);
    }
    if (!agentsMap.has(id)) {
      // populate agentsMap where agentId is the key
      agentsMap.set(id, new circle());
      agentsMap.get(id).name = agentsObj[i].name;
      agentsMap.get(id).email = agentsObj[i].email;
    }
    agentsMap.get(id).online(id);
    agentsMap.get(id).stateChange(agentsObj[i].agentStatus);
  }
  gaps();
}

function renderLegend() {
  var legendHtml = "";
  var total = 0;
  for (let [state, value] of states.getAllStates()) {
    legendHtml +=
      '<input type="color" class="dot ' +
      state +
      '" id="Color' +
      state +
      '" style="background-color: ' +
      value[0] +
      ';" value="' +
      value[0] +
      '">';
    legendHtml +=
      '<span id="' + state + 'Leg">' + state + " : </span>";
    legendHtml += '<span id="' + state + '">' + value[1] + '</span><br />';
    total += value[1];
  }
  legendHtml += '<span class="dot" style="background-color: black;"></span>';
  legendHtml += '<span id="agentsLeg">Agents: </span>';
  legendHtml += '<span id="Agents">' + total + '</span><br />';
  document.getElementById("legend").innerHTML = legendHtml;
  setupColorChanger();
}
/*------*/

/*Main Loop*/
function test() {
  if (demostate == 1) {
    getAllAgents();
    //real time state of agent counter
    var total = 0;
    for (let [state, value] of states.getAllStates()) {
      document.getElementById(state).innerHTML = value[1];
      total += value[1];
    }
    states.resetAll();
    document.getElementById("Agents").innerHTML = total;
  }
}
/*---------*/

function setup() {
  /*Popup Menu*/
  btn.addEventListener("click", display);
  //  when the user clicks on X button,close the modal
  close_btn.addEventListener("click", hide);
  // when user clicks anywhere outside the modal, close modal
  window.addEventListener("click", (event) => {
    if (event.target == modal) {
      hide();
    }
  });
  /*-----------*/
  /*Agent Info*/
  close1_btn.addEventListener("click", hideAgentInfo);
  /*----------*/
  gaps();
  renderLegend();
  setInterval(test, 1000); //speed/rate
}
/* ----------------- */

/* ---- Run ---- */
setup();
